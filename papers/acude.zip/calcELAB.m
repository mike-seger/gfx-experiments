function elab = calcELAB( a1, a2, b )
% elab = calcELAB( a1, a2, b );
%   Calculate and return the mean error in LAB space between color images a1 and a2 excluding b border pixels

[m,n,k] = size(a1);
bm = b(1);
if (numel(b)==1)  bn = bm;  else  bn = b(2);  end;
a1 = RGB2Lab( a1((1+bm):(m-bm), (1+bn):(n-bn), :) );
a2 = RGB2Lab( a2((1+bm):(m-bm), (1+bn):(n-bn), :) );
elab = mean2( sqrt(sum( (a1-a2).^2, 3)) );

end