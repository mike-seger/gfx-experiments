function mse = calcMSE( a1, a2, b )
% mse = calcMSE( a1, a2, b );
%   Calculate and return MSE between color images a1 and a2 excluding b border pixels

[m,n,k] = size(a1);
bm = b(1);
if (numel(b)==1)  bn = bm;  else  bn = b(2);  end;
mse = sum(sum( ( a1((1+bm):(m-bm), (1+bn):(n-bn), :) - a2((1+bm):(m-bm), (1+bn):(n-bn), :) ).^2 ))/(m-2*bm)/(n-2*bn);
mse = reshape(mse,[1,k]);

end