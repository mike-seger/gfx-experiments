function We = EdgeWeights( a, dif, smooth5 )
% We = EdgeWeights( a )
%  generate the edge sensing weights
% 
% by Pengwei Hao, 2012-6

[mImage, nImage] = size(a);
nDiff = length(dif);

We = zeros(mImage, nImage, nDiff);
for k = 1:nDiff,
    We(:,:,k) = imfilter(a, dif{k}, 'replicate' );
    We(:,:,k) = imfilter(abs(We(:,:,k)).^2, smooth5, 'replicate' );
end;
ap = 5/1000;
e2 = mean(We,3)*2;  % the energy of the edges in all directions
e2( e2 < ap*max(e2(:)) ) = intmax;  % in order to set 1 all weights for the small edges (ap)
for k = 1:nDiff,
%     We(:,:,k) = link(We(:,:,k)./e2, x1, 1, x2, 0);  % apply to the function for proper adaptive weighting
    We(:,:,k) = 1 - We(:,:,k)./e2;  % apply to the function for proper adaptive weighting
end;  % end of weights generation
We(We<0) = 0;
We(We>1) = 1;

end