function [Tmx, Dem] = getMatrices( pCFA )
% To find the optimal transform matrices of multiplexing and demosaicking for all the CFA pixels
%   pCFA(1:m,1:n,1:3) : the colors of the given CFA for imaging
%   Tmx and Dem matrices both are of size [m,n,3,3]. This is for all CFAs.
% If a CFA has only a small number of colors, it is not necessary to have
%   such large matrices and just use the following  to find the matrices:
%   Tmx(r,g,b) = [r,g,b;1,-1,0;r/(r+g),g/(r+g),-1];   % Multiplexing matrix, r>=g>=r
%   Dem(r,g,b) = [1,g/(r+g),b;1,-r/(r+g),b;1,0,b-1];  % Demosaicking matrix, r>=g>=r
% 
% by Pengwei Hao, 2012-6

[m,n,k] = size(pCFA);

Tmx = zeros([m,n,3,3]);
Dem = zeros([m,n,3,3]);

for i = 1:m,
  for j = 1:n,
    c = reshape(pCFA(i,j,:),[1,3]);  % Central pixel color
    [c,ind] = sort( c, 'descend' );  % sort in descending order
    Tmx(i,j,:,ind) = [c(1),c(2),c(3); 1,-1,0; c(1)/(c(1)+c(2)),c(2)/(c(1)+c(2)),-1];  % Tmx(:,:,1,:): colors, Tmx(:,:,2:3,:): 2 chromas 
    Dem(i,j,:,:) = inv( reshape(Tmx(i,j,:,:),[3,3]) );  % Dem: the inverse of Tmx for the demosaicking transform matrix of [3,3]
  end;
end;

end