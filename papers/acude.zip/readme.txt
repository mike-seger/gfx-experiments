This text file is to give you more information about the code and our universal demosaicking method, which can be used for all Colour Filter Arrays. It is non-iterative, and can be linear (image-independent) or nonlinear (image-dependent), so it is good for CFA demosaicking, design and comparison.

The provided files are only for demonstration of our ACUDe method for the Bayer CFA pattern, and are implemented naively, thus they may run slowly. If you wish us to test our method on your CFA patterns, we are also happy to do it. Please contact us. 

Actually the algorithm can be implemented very fast, which can be faster than 1 second/image with MATLAB and can be even much faster with C or with the help of some hardware. Please contact Pengwei Hao for further information: p.hao@qmul.ac.uk

If the code or the method is used for research, please cite:

Chao Zhang, Yan Li, Jue Wang, and Pengwei Hao, "Universal Demosaicking of Color Filter Arrays", IEEE Transactions on Image Processing, Vol. xx, No. xx, pp. xxxx-xxxx, 2016.
DOI: 10.1109/TIP.2016.2601266 
Available on http://ieeexplore.ieee.org/document/7547314/

More information can be found:
http://www.eecs.qmul.ac.uk/~phao/CFA/acude/

List of the provided functions:
acudemain    : The main MATLAB function to demonstrate our ACUDe method for the Bayer CFA pattern
acude        : Apply our adaptive chrominance-based universal demosaicking method ACUDe to obtain the 2 chrominance components at each pixel
EdgeWeights  : Generate the edge sensing weights
filter2matrix: convert a filter into a system matrix
getMatrices  : Find the optimal transform matrices of multiplexing and demosaicking for CFA pixels
CC2RGB       :  Apply the demosaicking transform to find the RGB images from chrominance estimates
LAB2RGB      : Convert an image from CIELAB to RGB
RGB2LAB      : Convert an image from RGB to CIELAB
calcMSE      : Calculate MSE between two color images
calcELAB     : Calculate the mean error in LAB space between two color images

Pengwei Hao, 18 August 2016