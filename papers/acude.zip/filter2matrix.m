function H = filter2matrix( h, m, n )
% H = filter2matrix(h, m, n)
%     To convert a 2D filter matrix h into a system matrix of size [(m-mh+1)*(n-nh+1),m*n]
%     such that reshape(H*reshape(f,m*n,1),(m-mh+1),(n-nh+1)) == filter2(h,f,'valid')
%     no border extension is applied.
% 
% by Pengwei Hao, 2012-6

[mh,nh] = size(h);

H = zeros((m-mh+1)*(n-nh+1),m*n);
for j = 1:(n-nh+1),
  for i = 1:(m-mh+1),
    h1 = zeros(m,n);
    h1(i-1+(1:mh),j-1+(1:nh)) = h;
    H((j-1)*(m-mh+1)+i, :) = h1(:);
  end;
end;

end