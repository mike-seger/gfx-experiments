function err = acudemain(iCFA)
% this is for the main function to demonstrate ACUDe method for 
% the Bayer CFA pattern

if (nargin<1) iCFA = 1; end;

adaptive = true;  % false;  % adaptive (with edge-sensing weights) or nonadaptive (linear demosaicking)

pCFA0 = [  % Bayer CFA in a 2x6 matrix
 0 1, 1 0, 0 0
 0 0, 0 1, 1 0 ];
pCFA0 = reshape(pCFA0, [2,2,3]);  % Bayer CFA converted back into a 2x2x3 matrix
% This is for the example to demonstrate our acude function. 
% Actually the CFA can be all kinds of CFAs, periodic or aperiodic (random).

[mCFA, nCFA, nColors] = size(pCFA0);

sDataSet = 'Kodak';

load('weights.mat');
weights2(:,:,2) = weights2(:,:,1)';
weights2(:,:,3) = weights2(:,:,1)';
weights2(:,:,4) = weights2(:,:,1);   % weights for adaptive demosaicking
weights2p = weights2.*(weights2>0);  % positive distance-related weights
mBdr1 = floor(size(weights1,1)/2) +1;  % border pixels
nBdr1 = floor(size(weights1,2)/2) +1;  % border pixels
mBdr2 = floor(size(weights2,1)/2) +1;  % border pixels
nBdr2 = floor(size(weights2,2)/2) +1;  % border pixels

a = 0.8668;  dif = [a,1-a,a; 1-a,-4,1-a; a,1-a,a]/4;
dif1 = {dif};   % for inter-pixel chrominance capture (nonadaptive demosaicking) 
dif2{1} = [0,1,0; 0,-1,0; 0,0,0];  % for inter-pixel chrominance capture (adaptive demosaicking)
dif2{2} = [0,0,0; 1,-1,0; 0,0,0];  % for inter-pixel chrominance capture (adaptive demosaicking)
dif2{3} = [0,0,0; 0,-1,1; 0,0,0];  % for inter-pixel chrominance capture (adaptive demosaicking)
dif2{4} = [0,0,0; 0,-1,0; 0,1,0];  % for inter-pixel chrominance capture (adaptive demosaicking)

nFiles = 24;
mseAll = zeros(nFiles,4);

for iFile = 1:nFiles,

fImage = sprintf('kodim%02d.png',iFile);

a0 = double(imread(fImage));
[mImage, nImage, nColors] = size(a0);

pCFA = pCFA0(mod((1:mImage)-1,mCFA)+1, mod((1:nImage)-1,nCFA)+1, :);  % to make the CFA pattern tiled in the same size as the input image
aCFA = sum( a0.*pCFA, 3);       % to simulate the acquired CFA-filtered image
[Tmx,Dem] = getMatrices(pCFA);  % to generate the multiplexing matrices and the demosaicking matrices, one 3x3 matrix at each pixel

CC = acude( aCFA, Tmx, dif1, [], weights1 );  % nonadaptive demosaicking with all weights
aR = CC2RGB(aCFA, CC, Dem, [mBdr1,nBdr1] );   % demosaicking transformation back to RGB image
if adaptive   %  adaptive demosaicking
  we = EdgeWeights( mean(aR, 3), dif2, smooth5 );  % edge-sensed weights generated with the luma of the image obtained by nonadaptive demosaicking
  CCh = acude( aCFA, Tmx, dif2, we, weights2 );    % adaptive demosaicking with all weights
  CCp = acude( aCFA, Tmx, dif2, we, weights2p );   % adaptive demosaicking with positive weights only
  CC  = 5*CCp - 4*CCh;   % Linear combination to keep the solution with the all weights
  aR = CC2RGB(aCFA, CC, Dem, [mBdr2,nBdr2] );  % demosaicking transformation back to RGB image
end;

mBorder = max(mBdr1,mBdr2);   % border row pixels
nBorder = max(nBdr1,nBdr2);   % border column pixels

mse = calcMSE(  a0, aR, [mBorder,nBorder] );
lab = calcELAB( a0, aR, [mBorder,nBorder] );

mseAll(iFile,:) = [mse,lab];

% Output the errors for each image
fmse = fopen('error.txt','a+');
fprintf(fmse,'%2d  %02d ', [iCFA, iFile]);
fprintf(fmse,' %10.6f',[lab, mse, mean(mse)]);
fprintf(fmse,' ');
fprintf(fmse,' %10.6f', [10*log10(255^2./mse), 10*log10(255^2/mean(mse))]);
fprintf(fmse,'\r\n');
fclose(fmse);

end % for iFile

meanmse = mean(mseAll(:,1:3),1);  % mean for all images
elab =  mean(mseAll(:,4),1);      % CIE LAB error
cmse = mean(meanmse);             % mean for all colors

err = cmse;  % or return  elab  %

% Output the mean errors
fmse = fopen('error.txt','a+');
fprintf(fmse,'%2d mean', iCFA);
fprintf(fmse,' %10.6f',[elab, meanmse, cmse]);
fprintf(fmse,' ');
fprintf(fmse,' %10.6f', [10*log10(255^2./meanmse), 10*log10(255^2/cmse)]);
fprintf(fmse,'\r\n');
fclose(fmse);

end