function RGB = CC2RGB(imgCFA, CC, Dem, Border )
% RGB = CC2RGB(imgCFA, CC, Dem )
%   To apply the demosaicking transform to the CFA-filtered image and the
%   estimated 2 chrominance components to find the RGB images.
%
% by Pengwei Hao, 2012-6

[mImg,nImg] = size(imgCFA);
mBdr = Border(1);
if (numel(Border)==1)  nBdr = mBdr;  else  nBdr = Border(2);  end;

RGB = zeros([mImg,nImg,3]);
for m = (mBdr+1):(mImg-mBdr),
  for n = (nBdr+1):(nImg-nBdr),
      RGB(m,n,:) = reshape( Dem(m,n,:,:), [3,3] ) * [imgCFA(m,n); reshape(CC(m,n,:),[2,1])];  % demosaicking transform
  end;
end;

% border pixels filled by replicating the nearest pixels:
for k = 1:3,
  RGB(1:mBdr,:,k) = ones([mBdr,1]) * RGB(mBdr+1,:,k);
  RGB(mImg-mBdr+(1:mBdr),:,k) = ones([mBdr,1]) * RGB(mImg-mBdr,:,k);
  RGB(:,1:nBdr,k) =  RGB(:,nBdr+1,k) * ones([1,nBdr]);
  RGB(:,nImg-nBdr+(1:nBdr),k) =  RGB(:,nImg-nBdr,k) * ones([1,nBdr]);
end;

RGB(RGB<0) = 0;  RGB(RGB>255) = 255;  % Saturation correction to fit into the dynamic range

end