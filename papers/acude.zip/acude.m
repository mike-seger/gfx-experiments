function CC = acude( imgCFA, Tmx, dif, imgEdge, weights )
% CC = acude( imgCFA, Tmx, dif, imgEdge, weights )
% To apply the adaptive chrominance-based universal demosaicking method and
%   obtain the 2 chrominance components at each pixel from the CFA-filtered
%   image and the corresponding CFA colors.
% imgCFA  : the CFA-filtered image, acquired from CFA camera.
% Tmx     : the multiplexing matrices, Tmx(m,n,:,:) is a 3x3 trasform matrix
%             the first row Tmx(m,n,1,:) is the CFA color, and the other 2
%             rows Tmx(m,n,2:3,:) are for the chrominance directions.
% dif     : 3x3 matrix/matrices for the inter-pixel chrominance capture.
% imagEdge: the edge-sensed weights given as an image.
% weights : the distance-related weights.
% CC      : returned image with 2 chrominance amplitudes at each pixel.
% 
% We have implemented the fast algorithm of this function. Please contact
%   phao@eecs.qmul.ac.uk for further information
% 
% by Pengwei Hao, 2012-6

adaptive = (length(imgEdge)>1);

[mImg,nImg] = size(imgCFA);
[mWts,nWts,nDiff] = size(weights);  % weights size
mBdr = floor(mWts/2) +1;  % border pixels
nBdr = floor(nWts/2) +1;  % border pixels

G = zeros([nDiff*mWts*nWts,(mWts+2)*(nWts+2)]);
for k = 1:nDiff,
  G((k-1)*mWts*nWts+(1:(mWts*nWts)),:) = filter2matrix( dif{k}, mWts+2, nWts+2 );  % matrix for inter-pixel chrominance capture
end;

CC = zeros([mImg,nImg,2]);
for m = 0:(mImg-mWts-2),
%  fprintf('%d/%d ',m+1,(mImg-mWts-1));
%  if (mod(m+1,10)==0)  fprintf('\n');  end;
  for n = 0:(nImg-nWts-2),
      F = reshape( Tmx(m+(1:(mWts+2)),n+(1:(nWts+2)),1,:), [(mWts+2)*(nWts+2),3]);  % CFA colors in the block

      We = 1;     % non-adaptive weights: distance-related only
      if adaptive
        We = imgEdge(m+(2:(mWts+1)),n+(2:(nWts+1)),:);  % edge-sensed weights
      end;
      W = diag(We(:).*weights(:));  % adaptive weights: with both distance-related and edge-sensitive weights

      pq = reshape( Tmx(m+mBdr+1,n+nBdr+1,2:3,:), [2,3]);   % chrominance directions

      h = pq*pinv(W*G*F)*W*G;     % weights for the chrominance directions and amplitudes

      f = reshape( imgCFA(m+(1:(mWts+2)),n+(1:(nWts+2))),  [(mWts+2)*(nWts+2),1]);  % image block

      CC(m+mBdr+1,n+nBdr+1,:) = h*f;    % chrominacne amplitudes
  end;
end;

end